from setuptools import setup

setup (

    name="Paquete calculos",
    version="1.0",
    descripcion="Calcula la edad de una persona",
    author="Jaibol",
    author_email="jaibolsantaella@gmail.com",
    url="profesionalesdevenezuela.org.ve",
    #package=["Directorio","SubDirectorio.Modulo"]
    package=["CarpetaPaquetes","SubModulos.Calcular"]

)

'''
Abrir un terminal y crear un archivo distribuible

cd /raiz-del-proyecto

python3 setup.py sdist


'''