'''
Este módlulo ha sido guardado en un directorio junto a otros módulos más, y en la raiz de éste está un archivo "__init__.py"
'''


def sumar (op1,op2):
    print ("\n El resultado de la suma es: " ,  op1+op2)

def restar (op1,op2):
    print ("\n El resultado de la resta es: " ,  op1-op2)

def multiplicar (op1,op2):
    print ("\n El resultado de la multiplicacion es: " ,  op1*op2)

def dividir (dividiendo,divisor):
 print ("\n El resultado de la división es: " ,  dividiendo/divisor)

def potencia (base, exponente):
 print ("\n El resultado de la potencia es: " ,  base**exponente)

def redondear (numero):
 print ("\n El resultado luego de redondear es : " ,  round(numero))