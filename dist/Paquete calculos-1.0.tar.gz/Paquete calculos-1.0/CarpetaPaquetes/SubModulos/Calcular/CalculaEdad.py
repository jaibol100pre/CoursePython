#Python
def calculaEdad():
    anio_nacimiento=int(input("Introduce el año de nacimiento"))
    anio_actual=int(input("Introduzca el año actual"))
    edad=anio_actual-anio_nacimiento
    return edad

