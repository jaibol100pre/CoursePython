'''
este módulo se encuentra en un sub directorio del directorio raiz CarpetaPaquetes o sea el módulo

'''

def redondear (numero):
 print ("\n El resultado luego de redondear es : " ,  round(numero))